---
title: "View usage analytics for Team and Enterprise plans"
title_slug: "view-usage-analytics-for-team-and-enterprise-plans"
source_url: "https://support.claude.com/en/articles/12883420-view-usage-analytics-for-team-and-enterprise-plans"
last_updated_iso: "2026-04-09T14:21:16Z"
article_id: "14575680"
breadcrumbs:
  - "Team and Enterprise plans"
  - "Analytics and usage"
---

# View usage analytics for Team and Enterprise plans

_Last updated: 2026-04-09T14:21:16Z_

This article explains how to view and export usage analytics for your organization.

> Usage analytics are available to Team plan Owners and Primary Owners, and Enterprise plan Owners, Primary Owners, and Admins. Enterprise Admins can view all analytics except Spend.

Usage analytics help you track team activity, feature adoption, and spend directly from your admin dashboard. You can monitor how your organization uses Claude and export detailed reports for your own analysis.

Primary Owners and Owners can access analytics via dedicated Analytics settings by clicking your initials in the lower left corner and selecting **[Analytics](https://claude.ai/analytics/activity)** from the menu. Additionally, the Claude.ai, Claude Code, and Cowork options offer product-specific analytics.

---

## All activity

This page includes the following analytics:

## Usage

- Weekly active users (WAU)
- Utilization rates (WAU / total seats)
- Pending invites
- Daily, weekly, and monthly active users, with filters for Claude (chat), Claude Code, and Claude Cowork
- Top connectors

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/2153394909/693f3ae0ec2ea158a1f1e233c024/CleanShot+2026-03-11+at+14_52_44%402x.png?expires=1776784500&signature=617e2bec60ebba931c5da39f33aeeeb442aba1852db88f2b3cd7560b56b50f69&req=diEiFcp3mYhfUPMW1HO4zbQxH8U2ByZnSPAYazQ9kuKIzbSHIrgoLwYk9EMc%0Am1e4LWyxM%2BpldkVzxek%3D%0A)

## Spend

> **Note:** If you're on a **[seat-based Enterprise plan](https://support.claude.com/en/articles/13393991-purchase-and-manage-seats-on-enterprise-plans#h_6a78e30e26)**, spend reports only appear if your organization has **[enabled extra usage](https://support.claude.com/en/articles/12005970-extra-usage-for-team-and-seat-based-enterprise-plans#h_2b9c54b46d)**. The spend data covers overage spend only—usage within seat-based allotments isn't included.

This section includes the following analytics:

- Total spend (month-to-date, quarter-to-date, year-to-date)
- Spend by model (1 month, 3 months, 1 year)
- Top 10 users by spend leaderboard

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/2153417518/03accc4372c7fd4582e6c3978d9d/CleanShot%2B2026-03-11%2Bat%2B15_02_52-402x.png?expires=1776784500&signature=f5a1ed02c193bbe1224b7b4c03276e3020690872b7533ac7bf4b35b97931c93f&req=diEiFc1%2FmoReUfMW1HO4zdUtwHoAMClLuwPrchh43EquFJ8JERAIgsf3XW8v%0ACzUn4RB1yJLZxDu3uFg%3D%0A)

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/2153419527/18cba69667e2af1a6f4f2e5ca2c5/CleanShot+2026-03-11+at+15_03_28%402x.png?expires=1776784500&signature=b08b16f892726e7cc8af196a88bcb768266c6a3645ba6a1a8d9a3838ef31a597&req=diEiFc1%2FlIRdXvMW1HO4zdGt9SKvA%2FtsP9LVpsbj5NeIPxJS%2F6XT27OzFyvb%0AbOd07udtrAeHjheg%2Bbw%3D%0A)

> **Note:** The spend leaderboard can be delayed by one to two days. For more current month-to-date spend per user, refer to spend limits by person in **[Organization settings > Usage](https://claude.ai/admin-settings/usage)**.

## Export a spend report

You can export a detailed cost and usage report as a CSV file. The report provides per-user, per-model visibility into token usage and estimated spend, updated daily.

To export spend data:

1. Navigate to **[Settings > Analytics](https://claude.ai/analytics/activity)**.
2. Scroll down to the **Spend** section.
3. Click the "Export Spend Report" button.
4. Select a time period: MTD, Last Month, Last 90 Days, or Custom.
5. If you select "Custom," choose your start and end dates. You can go back up to 90 days, and the most recent data available is from yesterday.
6. Click "Download."

#### What's included in the report?

Each row in the CSV represents a specific person's usage of a specific model on a given day. The report includes the following fields:

- Date
- Organization UUID
- User's email
- Account UUID
- Product (such as Chat, Claude Code, Cowork, or Office Agents)
  - Office Agents aggregates usage from the Claude add-ins for Excel, PowerPoint, and Word.
- Model and model family
- Request count (`total_requests`)
  - The count of individual API calls made to Claude. Each time an app or user sends a message and gets a response, that counts as a request.
- Prompt tokens (`total_prompt_tokens`)
  - The number of tokens consumed by the input side of each request. This includes system prompts, conversation history, user messages, tool definitions, etc.
- Completion tokens (`total_completion_tokens`)
  - The number of tokens generated by Claude when it responds*, *including extended thinking tokens.
- Net spend (`total_net_spend_usd`)
  - Your cost (in USD) after any discounts, credits, or negotiated rates are applied. This is what you actually spent.
- Gross spend (`total_gross_spend_usd`)
  - Your cost (in USD) before any discounts or credits.

> **Important:** Spend data refreshes daily and has a one-day delay. For usage-based Enterprise plans, the export captures your organization's full usage. For seat-based Enterprise plans with extra usage enabled, **the export only reflects spend that exceeds your seat allotment**.

---

## Claude.ai

Navigate to **[Analytics > Claude.ai](https://claude.ai/analytics/usage)** to view usage and activity metrics for your organization. This page includes the following analytics:

## Chats

- Chats per day
- Percentage of users with 1 or more chat
- Total number of chats (1 week, 1 month, 3 months, 1 year)

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/1916169034/e3e557f223fcd6976fa5b6353095/CleanShot+2026-01-05+at+15_32_41.png?expires=1776784500&signature=ec0665dad3a2aa8a57a651f31f63e3350646f31491fbeeea3001a43e15c377ce&req=dSkmEMh4lIFcXfMW1HO4zZyh%2BjWZ9o1%2BRyyyIe2wZ0ULvC4N5pAqxKzbPJgm%0AveeS8DivU4Qszf7j1%2BM%3D%0A)

## Projects

- Projects created per day
- Percentage of users with 1 or more project
- Top 10 users by projects used (month-to-date, quarter-to-date, year-to-date, 1 year)

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/1916170133/666961061f9a044385e0ea1debdd/CleanShot+2026-01-05+at+15_36_27.png?expires=1776784500&signature=989fbeb41cbeb1ade3c85497c7144b217cd56b6f04f2698936377ce125e5e41a&req=dSkmEMh5nYBcWvMW1HO4zed15SLp1RxfqVPXIl8sPebkwpU13iZiP7O61O0D%0AGTyESvbhqye1qB9kpoE%3D%0A)

## Artifacts

- Artifacts created per day
- Percentage of users with 1 or more artifact
- Top 10 users by artifacts generated (month-to-date, quarter-to-date, year-to-date, 1 year)

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/1916171160/cd17d2abba34659b9d8f6231df5a/CleanShot+2026-01-05+at+15_37_20.png?expires=1776784500&signature=6004b60aae1d3f054f972f2e81f4f1dc09f084eeb67c72a571ae803d771ad7d1&req=dSkmEMh5nIBZWfMW1HO4zXYF3l%2FltQT84Jgm1Axxim1lp9Lj8BmncXnKCuVI%0AMAYe510ivsnD0xq%2B6e4%3D%0A)

---

## Claude Code analytics

Navigate to **[Analytics > Claude Code](https://claude.ai/analytics/claude-code)** to view usage and activity metrics for your organization. For more specific details, refer to **[Claude Code usage analytics](https://support.claude.com/en/articles/12157520-claude-code-usage-analytics)**.

---

## Claude Cowork analytics

Navigate to **[Analytics > Cowork](https://claude.ai/analytics/cowork)** to view usage and activity metrics for Claude Cowork across your organization. This page includes:

- Cowork sessions per day
- Percentage of users with one or more Cowork sessions
- Daily, weekly, and monthly active Cowork users

![Embedded media](https://downloads.intercomcdn.com/i/o/lupk8zyo/2253604219/0d21918d55e10b3e5d2a92e65c90/42a47632-08c2-4557-a087-fc080c4dda80?expires=1776784500&signature=dc9b611fd48bf51120df905081a7f0d393d5ce44e28aefa8c7c186c022e750a6&req=diIiFc9%2BmYNeUPMW1HO4zSCqqKIAHHsb8zs2pRdG0k6gE2wtEejEPsXKyyF%2F%0A8SzPlXgjR39k9H%2BM1Kk%3D%0A)

> **Note:** Cowork analytics are available alongside Chat and Claude Code data in the **[Analytics API](https://support.claude.com/en/articles/13694757-access-engagement-and-adoption-data-with-the-analytics-api)**.

---

## Access your analytics data programmatically

If you’re on an Enterprise plan and want to pull analytics data into your own dashboards or reporting tools, the Analytics API gives you programmatic access to the same usage and engagement metrics available in the analytics dashboard. To get started, refer to **[Access usage data with the Analytics API](https://support.claude.com/en/articles/13694757-access-usage-data-with-the-analytics-api)**.

## Related Articles
- [What is the Enterprise plan?](https://support.claude.com/en/articles/9797531-what-is-the-enterprise-plan)
- [Manage extra usage for Team and seat-based Enterprise plans](https://support.claude.com/en/articles/12005970-manage-extra-usage-for-team-and-seat-based-enterprise-plans)
- [Claude Code usage analytics](https://support.claude.com/en/articles/12157520-claude-code-usage-analytics)
- [Claude Enterprise Analytics API: Access engagement and adoption data](https://support.claude.com/en/articles/13694757-claude-enterprise-analytics-api-access-engagement-and-adoption-data)
- [Claude Enterprise Analytics API reference guide](https://support.claude.com/en/articles/13703965-claude-enterprise-analytics-api-reference-guide)
